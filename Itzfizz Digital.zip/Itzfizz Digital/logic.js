// Select all images
const images = document.querySelectorAll('.image');

// Track mouse movement and animate images based on cursor proximity
document.addEventListener('mousemove', (e) => {
  const cursorX = e.clientX;
  const cursorY = e.clientY;

  images.forEach((image) => {
    const rect = image.getBoundingClientRect();
    const imageCenterX = rect.left + rect.width / 2;
    const imageCenterY = rect.top + rect.height / 2;

    const deltaX = cursorX - imageCenterX;
    const deltaY = cursorY - imageCenterY;

    const moveLimit = 30;
    const moveX = Math.max(-moveLimit, Math.min(moveLimit, deltaX / 15));
    const moveY = Math.max(-moveLimit, Math.min(moveLimit, deltaY / 15));

    image.style.transform = `translate(${moveX}px, ${moveY}px) scale(1.05)`;
  });
});

// Reset image positions when the mouse leaves the container
document.addEventListener('mouseleave', () => {
  images.forEach((image) => {
    image.style.transform = 'translate(0, 0) scale(1)';
  });
});
